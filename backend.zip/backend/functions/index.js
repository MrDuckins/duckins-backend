const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();

exports.updateOnlineTime = functions.pubsub
  .schedule('every 1 minutes')
  .onRun(async (context) => {
    // Tutaj dodaj logikę pobierania graczy online
    // (np. z Twojego API serwera Minecraft)
    
    // Przykładowa implementacja:
    const players = ['Gracz1', 'Gracz2']; // Tutaj wstaw prawdziwą listę
    
    const batch = db.batch();
    
    players.forEach(playerName => {
      const playerRef = db.collection('players').doc(playerName);
      batch.set(playerRef, {
        name: playerName,
        totalSeconds: admin.firestore.FieldValue.increment(60),
        lastSeen: admin.firestore.FieldValue.serverTimestamp()
      }, { merge: true });
    });
    
    await batch.commit();
    console.log(`Zaktualizowano ${players.length} graczy`);
    return null;
});